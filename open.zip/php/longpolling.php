<?php
$conn = new mysqli("localhost", "code147", "code1417.", "code147");
if (!$conn) {
	die("Connection failed: " . mysqli_connect_error());
}

$sql = "SELECT id FROM a";

$uuid = $_POST['uuid'];
$rownum = $_POST['num'];


for ($i = 1; $i < 60; $i++) {
	$result = mysqli_query($conn, $sql);
	if($rownum != mysqli_num_rows($result)){
		require 'poll.php';
        exit(0);
	}
	sleep(1);
}
