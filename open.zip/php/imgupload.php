<?php
header("Content-Type: text/html;charset=utf-8");

$conn = new mysqli("localhost", "code147", "code1417.", "code147");
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

$destination = '../img/';
$file = $_FILES['file']; // 获取上传的图片
$filename = $file['name'];

// 数据库信息
$uuid = '0';
// $text = "<img src=" . $destination .  . ">";
$pos = "normal";
$date = "";

$test = move_uploaded_file($file['tmp_name'], $destination . iconv("UTF-8", "gb2312", $filename));
$insert = "INSERT INTO a (uuid, position, date, text) VALUES ('".$uuid."', '".$pos."', '".$date."','".$text."')";

if ($insert && $test) {
  $conn->query($insert);
} else {
  echo '上传失败' . '<br>';
}