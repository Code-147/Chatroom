﻿<?php
$conn = new mysqli("localhost", "code147", "code1417.", "code147");
if (!$conn) {
	die("Connection failed: " . mysqli_connect_error());
}

$silent_Status = file_get_contents("silent.log");

$uuid = $_POST['uuid'];
$pos = $_POST['pos'];
$date = $_POST['date'];
$text = $_POST['text'];
$name = $_POST['name'];
//进行COMMAND判断
if ((strpos($text, '%2FC%20')) > -1){
	
    if ((strpos($text, '%2FC%20CLEAN')) > -1){
		$sql = "DELETE FROM a";
		mysqli_query($conn, $sql);
		$sql = "ALTER TABLE a AUTO_INCREMENT = 1";
		mysqli_query($conn, $sql);
		$date = "管理员清除了聊天记录";
		$text = "/SYSTEMMSG";
    Update();
		
	}else if((strpos($text, '%2FC%20SILENT')) > -1){
		$date = "已开启全员静音";
		$text = "/SYSTEMMSG";
		Update();
		file_put_contents('silent.log', 'true');
		
	}else if((strpos($text, '%2FC%20UNSILENT')) > -1){
		$date = "已退出全员静音";
		$text = "/SYSTEMMSG";
		Update();
		file_put_contents('silent.log', 'false');
	}
	
}else if($silent_Status == 'false'){
 	Update();
}
	
function Update(){
	global $conn,$text,$pos,$date,$uuid,$name;

	$sql = "INSERT INTO a (uuid, position, date, text, name) VALUES ('".$uuid."', '".$pos."', '".$date."','".$text."','".$name."')";
	
	mysqli_query($conn, $sql);
	mysqli_close($conn);
}