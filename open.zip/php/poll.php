﻿<?php
	header('content-type:application/json');
  $conn = new mysqli("localhost", "code147", "code1417.", "code147");
	if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
	}

	if (!$conn) {
    die("Connection failed: " . mysqli_connect_error()); 
  } 

	$sql = "SELECT id, uuid, date, text, name FROM a";
	$result = mysqli_query($conn, $sql);
 	
	if (mysqli_num_rows($result) > 0) {
    	// 输出数据
		$content = "[";
    	while($row = mysqli_fetch_assoc($result)) {
   		 	$content = $content.'{"id":"'.$row["id"].'","uuid":"'.$row["uuid"].'","date":"'.$row["date"].'","text":"'.$row["text"].'","name":"'.$row["name"].'"},';
		}
		$content = substr($content ,0 ,strlen($content)-1);
		$content = $content."]";
		echo $content;
	} else {
    	echo '[{"date": "", "text": ""}]';
	}
