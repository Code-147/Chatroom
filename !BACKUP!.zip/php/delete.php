﻿<?php
$conn = new mysqli("localhost", "code147", "code1417.", "code147");
if (!$conn) {
	die("Connection failed: " . mysqli_connect_error());
}

$uuid = $_POST['uuid']; //自身uuid
$obj_uuid = $_POST['obj_uuid'];  //要删除的目标对象的uuid
$pos = $_POST['pos'];  //自身权限
$id = $_POST['id'];  //要删除的目标对象的id

if ($pos == 'admin' || $obj_uuid == $uuid){
	Update();
	echo '删除成功';
}else{
	echo '无此权限';
}
	
function Update(){
	global $conn,$id;

	$sql = "DELETE FROM `a` WHERE ((`id` = '".$id."'));";
	
	mysqli_query($conn, $sql);
}
